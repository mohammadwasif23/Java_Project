/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package automatedpurchaseordermanagementsystem;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


/**
 *
 * @author Manreen
 */
public class PM_DisplayRequisition extends javax.swing.JFrame {

    private String username;
    /**
     * Creates new form PM_DisplayRequisition
     */
    public PM_DisplayRequisition() {
        Login login = new Login();
        username = login.getUsername();
        initComponents();
        loadTable();
        
       private void datePropertyChange(java.beans.PropertyChangeEvent evt) {                                    
        if ("date".equals(evt.getPropertyName())) {
            Date selectedDate = date.getDate();
            if (selectedDate != null) {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                String formattedDate = sdf.format(selectedDate);

                filterTableByPurchaseManagerAndDate(formattedDate);
            }
        }
    }                                   

    private void loadTable() {
        DefaultTableModel model = (DefaultTableModel) DisplayRequisitionjTable.getModel();
        model.setRowCount(0);

        String displayRequisition= "Requisition.txt";

        List<String> orderIds = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(displayRequisition))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("\\|");
                if (parts.length >= 13) {
                    String PRID = parts[11]; // Purchase Requistion ID
                    String SMID = parts[0];   // Sales Manager ID
                    if (PRID.equals(username)) {
                        SMID.add(SMID);
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading Requisition.txt: " + e.getMessage());
            return;
        }

        if (orderIds.isEmpty()) {
            System.out.println("No orders found for Purchase Requisition ID: " + username);
            return;
        }

        Map<String, String[]> feedbackMap = new HashMap<>();

        try (BufferedReader br = new BufferedReader(new FileReader(RequisitionFile))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("\\|");
                if (parts.length == 9) {
                    String PRID = parts[0];   // Purchase Requisition  ID
                    String SMID = parts[6];  // Sales Manager ID
                    String dateTxt = parts[8];

                    feedbackMap.put(PRID, new String[]{SMID, dateTxt});
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading Requisition.txt: " + e.getMessage());
            return;
        }

        // Purchase Requisition ID
        System.out.println("Sales Manager ID for Purchase Requisition ID: " + username);
        for (String PRID : orderIds) {
            if (feedbackMap.containsKey(PRID)) {
                String[] feedbackData = feedbackMap.get(PRID);
                model.addRow(new Object[]{PRID, feedbackData[0], feedbackData[1]});
            }
        }
    }

    private void filterTableByPurchaseManagerAndDate(String selectedDate) {
        DefaultTableModel model = (DefaultTableModel) DisplayRequisitionjTable.getModel();
        model.setRowCount(0);

        Map<String, List<String>> PRID = new HashMap<>();
        File orderFile = new File("Requisition.txt");

        if (orderFile.exists()) {
            try (BufferedReader br = new BufferedReader(new FileReader(orderFile))) {
                String line;
                while ((line = br.readLine()) != null) {
                    String[] data = line.split("\\|");
                    if (data.length >= 12) {
                        String orderId = data[0].trim();
                        String runnerId = data[11].trim();

                        PRID.computeIfAbsent(runnerId, k -> new ArrayList<>()).add(orderId);
                    }
                }
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "Error loading requisitions: " + e.getMessage());
                e.printStackTrace();
                return;
            }
        } else {
            JOptionPane.showMessageDialog(this, "File not found: " + orderFile.getAbsolutePath());
            return;
        }

        if (!PRID.containsKey(username)) {
            JOptionPane.showMessageDialog(this, "No requisitions found for Item Code: " + username);
            return;
        }

        List<String> validOrders = PRID.get(username);

        File RequisitionFile = new File("Requisition.txt");
        if (!RequisitionFile.exists()) {
            JOptionPane.showMessageDialog(this, "File not found: " + RequisitionFile.getAbsolutePath());
            return;
        }

        try (BufferedReader br = new BufferedReader(new FileReader(RequisitionFile))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split("\\|");
                if (data.length == 9) {
                    String PRID = data[0].trim();
                    String SMID = data[8].trim();
                    String ItemCode = data[6].trim();
                    Int Quantity = data[0].trim();
                    Int RequiredDate = data[8].trim();
                    String Status = data[6].trim();
                    if (validOrders.contains(PRID) && RequiredDate.equals(selectedDate)) {
                        model.addRow(new Object[]{PRID, SMID, ItemCode, Quantity, RequiredDate, Status});
                    }
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error loading requisition: " + e.getMessage());
            e.printStackTrace();
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        DisplayRequisitionjLabel = new javax.swing.JLabel();
        BackjButton = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        DisplayRequisitionjTable = new javax.swing.JTable();
        ViewjButton = new javax.swing.JButton();
        SelectDateForFilterjLabel = new javax.swing.JLabel();
        SelectDateForFilterjCalendar = new com.toedter.calendar.JCalendar();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(153, 204, 255));

        jPanel1.setBackground(new java.awt.Color(153, 204, 255));

        DisplayRequisitionjLabel.setFont(new java.awt.Font("Rockwell", 1, 36)); // NOI18N
        DisplayRequisitionjLabel.setText("Display Requisition");

        BackjButton.setBackground(new java.awt.Color(102, 153, 255));
        BackjButton.setFont(new java.awt.Font("Rockwell", 1, 18)); // NOI18N
        BackjButton.setText("Back");
        BackjButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        BackjButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackjButtonActionPerformed(evt);
            }
        });

        DisplayRequisitionjTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Purchase Requisition ID", "Sales Manager ID", "Item Code", "Quantity", "Required Date", "Status"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(DisplayRequisitionjTable);

        ViewjButton.setBackground(new java.awt.Color(102, 153, 255));
        ViewjButton.setFont(new java.awt.Font("Rockwell", 1, 18)); // NOI18N
        ViewjButton.setText("View");
        ViewjButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        SelectDateForFilterjLabel.setFont(new java.awt.Font("Rockwell", 0, 14)); // NOI18N
        SelectDateForFilterjLabel.setText("Select Date For Filter:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(BackjButton, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(243, 243, 243)
                        .addComponent(DisplayRequisitionjLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 363, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(45, 45, 45)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 858, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(SelectDateForFilterjLabel)
                                .addGap(18, 18, 18)
                                .addComponent(SelectDateForFilterjCalendar, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(46, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(ViewjButton, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(68, 68, 68))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addComponent(DisplayRequisitionjLabel))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(BackjButton, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(27, 27, 27)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(SelectDateForFilterjLabel)
                    .addComponent(SelectDateForFilterjCalendar, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 310, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50)
                .addComponent(ViewjButton, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(71, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BackjButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackjButtonActionPerformed
        this.dispose(); // Close the current window
        PurchaseManager_MainPage mainPage = new PurchaseManager_MainPage(); // Create a new instance of the main page
        mainPage.setVisible(true); // Show the main page
    }//GEN-LAST:event_BackjButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PM_DisplayRequisition.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PM_DisplayRequisition.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PM_DisplayRequisition.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PM_DisplayRequisition.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PM_DisplayRequisition().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BackjButton;
    private javax.swing.JLabel DisplayRequisitionjLabel;
    private javax.swing.JTable DisplayRequisitionjTable;
    private com.toedter.calendar.JCalendar SelectDateForFilterjCalendar;
    private javax.swing.JLabel SelectDateForFilterjLabel;
    private javax.swing.JButton ViewjButton;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
