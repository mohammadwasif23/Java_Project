/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package automatedpurchaseordermanagementsystem;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Manreen
 */
public class PM_ListOfPurchaseOrders extends javax.swing.JFrame {

    private String username;
    /**
     * Creates new form PM_ListOfPurchaseOrders
     */
    public PM_ListOfPurchaseOrders() {
        Login login = new Login();
        username = login.getUsername();
        initComponents();
        loadTable();
    }

    private void datePropertyChange(java.beans.PropertyChangeEvent evt) {                                    
        if ("date".equals(evt.getPropertyName())) {
            Date selectedDate = jCalendar1.getDate();
            if (selectedDate != null) {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                String formattedDate = sdf.format(selectedDate);

                filterTableByPurchaseManagerAndDate(formattedDate);
            }
        }
    }                                   

    private void loadTable() {
        DefaultTableModel model = (DefaultTableModel) ListOfPurchaseOrderjTable.getModel();
        model.setRowCount(0);

        String displayListOfPurchaseOrder= "ListOfPurchaseOrder.txt";

        List<String> ItemCode = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(displayListOfPurchaseOrder))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("\\|");
                if (parts.length >= 13) {
                    String POID = parts[11]; // Purchase Order ID
                    String PRID = parts[0];   // Purchase Requisition ID
                    String SupplierID = parts[12];
                    int OrderQuantity = Integer.parseInt(parts[0]);
                    String Status = parts[0];
                    
                    if (POID.equals(username)) {
                        PRID.add(PRID, SupplierID, OrderQuantity, Status);
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading ListOfPurchaseOrder.txt: " + e.getMessage());
            return;
        }

        if (ItemCode.isEmpty()) {
            System.out.println("No orders found for Purchase Order ID: " + username);
            return;
        }

        Map<String, String[]> ListOfOrderMap = new HashMap<>();

        try (BufferedReader br = new BufferedReader(new FileReader(ListOfPurchaseOrderFile))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("\\|");
                if (parts.length == 9) {
                    String POID = parts[0];   // Purchase Order  ID
                    String PRID = parts[6];  // Purchase Requisition ID
                    String dateTxt = parts[8];
                    String SupplierID = parts[12];
                    Int OrderQuantity = parts[0];
                    String Status = parts[0];

                    ListOfOrderMap.put(POID, new String[]{POID, dateTxt});
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading ListOfItems.txt: " + e.getMessage());
            return;
        }

        // Purchase Requisition ID
        System.out.println("POID for List of OrderID: " + username);
        for (String SupplierID : ItemCode) {
            if (ListOfOrderMap.containsKey(SupplierID)) {
                String[] ListOfItemsData = ListOfOrderMap.get(POID);
                model.addRow(new Object[]{SupplierID, ListOfItemsData[0], ListOfItemsData[1]});
            }
        }
    }

    private void filterTableByPurchaseManagerAndDate(String selectedDate) {
        DefaultTableModel model = (DefaultTableModel) ListOfPurchaseOrderjTable.getModel();
        model.setRowCount(0);

        Map<String, List<String>> POID = new HashMap<>();
        File ListOfItemsFile = new File("ListOfItems.txt");

        if (ListOfItemsFile.exists()) {
            try (BufferedReader br = new BufferedReader(new FileReader(ListOfItemsFile))) {
                String line;
                while ((line = br.readLine()) != null) {
                    String[] data = line.split("\\|");
                    if (data.length >= 12) {
                        String ItemCode = data[0].trim();
                        String PRID = data[0].trim();
                        String SupplierID = data[11].trim();

                        POID.computeIfAbsent(ItemCode, k -> new ArrayList<>()).add(SupplierID);
                    }
                }
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "Error loading order: " + e.getMessage());
                e.printStackTrace();
                return;
            }
        } else {
            JOptionPane.showMessageDialog(this, "File not found: " + ListOfPuchaseOrderFile.getAbsolutePath());
            return;
        }

        if (!POID.containsKey(username)) {
            JOptionPane.showMessageDialog(this, "No order found for Purchase Order ID: " + username);
            return;
        }

        List<String> validOrders = POID.get(username);

        File ListOfPurchaseOrderFile = new File("ListOfPurchaseOrder.txt");
        if (!ListOfItemsFile.exists()) {
            JOptionPane.showMessageDialog(this, "File not found: " + ListOfItemsFile.getAbsolutePath());
            return;
        }

        try (BufferedReader br = new BufferedReader(new FileReader(ListOfItemsFile))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split("\\|");
                if (data.length == 9) {
                    String POID = data[0].trim();
                    String PRID = data[8].trim();
                    String SupplierID = data[6].trim();
                    Int OrderQuantity = data[0].trim();
                    String Status = data[6].trim();
                    if (validOrders.contains(SupplierID) && data[7].equals(selectedDate)) { // Assuming index 7 is the date
                        model.addRow(new Object[]{POID, PRID, SupplierID, OrderQuantity, Status});
                    }
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error loading order: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        ListOfPurchaseOrderjLabel = new javax.swing.JLabel();
        BackjButton = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        ListOfPurchaseOrderjTable = new javax.swing.JTable();
        ViewjButton = new javax.swing.JButton();
        SelectDateForFilterjLabel = new javax.swing.JLabel();
        jCalendar1 = new com.toedter.calendar.JCalendar();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(153, 204, 255));

        jPanel1.setBackground(new java.awt.Color(153, 204, 255));

        ListOfPurchaseOrderjLabel.setFont(new java.awt.Font("Rockwell", 1, 36)); // NOI18N
        ListOfPurchaseOrderjLabel.setText("List Of Purchase Order");

        BackjButton.setBackground(new java.awt.Color(102, 153, 255));
        BackjButton.setFont(new java.awt.Font("Rockwell", 1, 18)); // NOI18N
        BackjButton.setText("Back");
        BackjButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        BackjButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackjButtonActionPerformed(evt);
            }
        });

        ListOfPurchaseOrderjTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "PO ID", "PR ID", "Supplier ID", "Order Quantity", "Status"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(ListOfPurchaseOrderjTable);

        ViewjButton.setBackground(new java.awt.Color(102, 153, 255));
        ViewjButton.setFont(new java.awt.Font("Rockwell", 1, 18)); // NOI18N
        ViewjButton.setText("View");
        ViewjButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        ViewjButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ViewjButtonActionPerformed(evt);
            }
        });

        SelectDateForFilterjLabel.setFont(new java.awt.Font("Rockwell", 0, 14)); // NOI18N
        SelectDateForFilterjLabel.setText("Select Date For Filter:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(ViewjButton, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(68, 68, 68))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(BackjButton, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(175, 175, 175)
                        .addComponent(ListOfPurchaseOrderjLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 424, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(45, 45, 45)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 858, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(SelectDateForFilterjLabel)
                                .addGap(18, 18, 18)
                                .addComponent(jCalendar1, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(46, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addComponent(ListOfPurchaseOrderjLabel))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(BackjButton, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(25, 25, 25)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(SelectDateForFilterjLabel)
                    .addComponent(jCalendar1, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 310, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 52, Short.MAX_VALUE)
                .addComponent(ViewjButton, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(71, 71, 71))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BackjButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackjButtonActionPerformed
        this.dispose(); // Close the current window
        PurchaseManager_MainPage mainPage = new PurchaseManager_MainPage(); // Create a new instance of the main page
        mainPage.setVisible(true); // Show the main page
    }//GEN-LAST:event_BackjButtonActionPerformed

    private void ViewjButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ViewjButtonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ViewjButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PM_ListOfPurchaseOrders.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PM_ListOfPurchaseOrders.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PM_ListOfPurchaseOrders.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PM_ListOfPurchaseOrders.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PM_ListOfPurchaseOrders().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BackjButton;
    private javax.swing.JLabel ListOfPurchaseOrderjLabel;
    private javax.swing.JTable ListOfPurchaseOrderjTable;
    private javax.swing.JLabel SelectDateForFilterjLabel;
    private javax.swing.JButton ViewjButton;
    private com.toedter.calendar.JCalendar jCalendar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
