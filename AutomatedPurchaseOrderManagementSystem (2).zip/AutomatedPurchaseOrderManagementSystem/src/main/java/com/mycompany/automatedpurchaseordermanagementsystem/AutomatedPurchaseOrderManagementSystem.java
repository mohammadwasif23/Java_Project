/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.automatedpurchaseordermanagementsystem;

import javax.swing.JFrame;

/**
 *
 * @author Manreen
 */
public class AutomatedPurchaseOrderManagementSystem {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }

    public class SalesManager_MainPage extends JFrame {
        // Class implementation
    }

    public class PurchaseManager_MainPage extends JFrame {
        // Class implementation
    }

    public class Administrator_MainPage extends JFrame {
        // Class implementation
    }

    public class InventoryManager_MainPage extends JFrame {
        // Class implementation
    }

    public class FinanceManager_MainPage extends JFrame {
        // Class implementation
    }
}
