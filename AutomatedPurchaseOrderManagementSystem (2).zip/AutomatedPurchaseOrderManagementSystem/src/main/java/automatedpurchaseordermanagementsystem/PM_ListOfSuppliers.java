/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package automatedpurchaseordermanagementsystem;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Manreen
 */
public class PM_ListOfSuppliers extends javax.swing.JFrame {

    private String username;
    /**
     * Creates new form PM_ListOfSuppliers
     */
    public PM_ListOfSuppliers() {
        Login login = new Login();
        username = login.getUsername();
        initComponents();
        loadTable();
        
       private void datePropertyChange(java.beans.PropertyChangeEvent evt) {                                    
        if ("date".equals(evt.getPropertyName())) {
            Date selectedDate = date.getDate();
            if (selectedDate != null) {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                String formattedDate = sdf.format(selectedDate);

                filterTableByPurchaseManagerAndDate(formattedDate);
            }
        }
    }                                   

    private void loadTable() {
        DefaultTableModel model = (DefaultTableModel) ListOfSupplierjTable.getModel();
        model.setRowCount(0);

        String displayRequisition= "ListOfSuppliers.txt";

        List<String> SupplierIds = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(displayRequisition))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("\\|");
                if (parts.length >= 13) {
                    String SupplierName = parts[11]; // Purchase Requistion ID
                    String SupplierCode = parts[0];   // Sales Manager ID
                    Int ContactNumber = parts[12];
                    if (SupplierName.equals(username)) {
                        SupplierName.add(SupplierName);
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading ListOfSuppliers.txt: " + e.getMessage());
            return;
        }

        if (SupplierIds.isEmpty()) {
            System.out.println("No suppliers found for Supplier Name: " + username);
            return;
        }

        Map<String, String[]> SupplierMap = new HashMap<>();

        try (BufferedReader br = new BufferedReader(new FileReader(ListOfSupplierFile))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("\\|");
                if (parts.length == 9) {
                    String SupplierCode = parts[0];   // Purchase Requisition  ID
                    String SupplierName = parts[6];  // Sales Manager ID
                    String ContactNumber = parts[8];

                    SupplierMap.put(SupplierCode, new String[]{SupplierName, ContactNumber});
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading ListOfSuppliers.txt: " + e.getMessage());
            return;
        }

        // Purchase Requisition ID
        System.out.println("Supplier Name for Supplier Code: " + username);
        for (String SupplierName : SupplierIds) {
            if (SupplierMap.containsKey(SupplierName)) {
                String[] ListOfSuppliersData = SupplierMap.get(SupplierName);
                model.addRow(new Object[]{SupplierName, ListOfSuppliersData[0], ListOfSuppliersData[1]});
            }
        }
    }

    private void filterTableByPurchaseManagerAndDate(String selectedDate) {
        DefaultTableModel model = (DefaultTableModel) ListOfSupplierjTable.getModel();
        model.setRowCount(0);

        Map<String, List<String>> SupplierName = new HashMap<>();
        File ListOfSupplierFile = new File("ListOfSuppliers.txt");

        if (ListOfSupplierFile.exists()) {
            try (BufferedReader br = new BufferedReader(new FileReader(ListOfSupplierFile))) {
                String line;
                while ((line = br.readLine()) != null) {
                    String[] data = line.split("\\|");
                    if (data.length >= 12) {
                        String SupplierName = data[0].trim();
                        String SupplierCode = data[11].trim();
                        Int ContactNumber = data[12].trim();

                        SupplierName.computeIfAbsent(SupplierName, k -> new ArrayList<>()).add(SupplierName);
                    }
                }
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "Error loading suppliers: " + e.getMessage());
                e.printStackTrace();
                return;
            }
        } else {
            JOptionPane.showMessageDialog(this, "File not found: " + ListOfSupplierFile.getAbsolutePath());
            return;
        }

        if (!SupplierName.containsKey(username)) {
            JOptionPane.showMessageDialog(this, "No supplier found for Supplier Code: " + username);
            return;
        }

        List<String> validSuppliers = SupplierName.get(username);

        File ListOfSuppliersFile = new File("ListOfSuppliers.txt");
        if (!ListOfSuppliersFile.exists()) {
            JOptionPane.showMessageDialog(this, "File not found: " + ListOfSuppliersFile.getAbsolutePath());
            return;
        }

        try (BufferedReader br = new BufferedReader(new FileReader(ListOfSuppliersFile))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split("\\|");
                if (data.length == 9) {
                    String SupplierName = data[0].trim();
                    String SuppliersCode = data[8].trim();
                    String ContactNumber = data[6].trim();
                    if (validSuppliers.contains(SuppliersCode) && SupplierName.equals(selectedDate)) {
                        model.addRow(new Object[]{SupplierName, SupplierName, ContactNumber});
                    }
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error loading supplier: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        ListOfSupplierjLabel = new javax.swing.JLabel();
        BackjButton = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        ListOfSupplierjTable = new javax.swing.JTable();
        ViewjButton = new javax.swing.JButton();
        SelectDateForFilterjLabel = new javax.swing.JLabel();
        SelectDateForFilterjCalendar = new com.toedter.calendar.JCalendar();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(153, 204, 255));

        jPanel1.setBackground(new java.awt.Color(153, 204, 255));

        ListOfSupplierjLabel.setFont(new java.awt.Font("Rockwell", 1, 36)); // NOI18N
        ListOfSupplierjLabel.setText("List Of Suppliers");

        BackjButton.setBackground(new java.awt.Color(102, 153, 255));
        BackjButton.setFont(new java.awt.Font("Rockwell", 1, 18)); // NOI18N
        BackjButton.setText("Back");
        BackjButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        BackjButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackjButtonActionPerformed(evt);
            }
        });

        ListOfSupplierjTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Supplier Code", "Supplier Name", "Contact Number"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(ListOfSupplierjTable);

        ViewjButton.setBackground(new java.awt.Color(102, 153, 255));
        ViewjButton.setFont(new java.awt.Font("Rockwell", 1, 18)); // NOI18N
        ViewjButton.setText("View");
        ViewjButton.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        SelectDateForFilterjLabel.setFont(new java.awt.Font("Rockwell", 1, 14)); // NOI18N
        SelectDateForFilterjLabel.setText("Select Date For Filter:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(BackjButton, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(246, 246, 246)
                        .addComponent(ListOfSupplierjLabel))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(45, 45, 45)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 858, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(SelectDateForFilterjLabel)
                                .addGap(18, 18, 18)
                                .addComponent(SelectDateForFilterjCalendar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(46, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(ViewjButton, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(68, 68, 68))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addComponent(ListOfSupplierjLabel))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(BackjButton, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(25, 25, 25)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(SelectDateForFilterjLabel)
                    .addComponent(SelectDateForFilterjCalendar, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 310, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 52, Short.MAX_VALUE)
                .addComponent(ViewjButton, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(71, 71, 71))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BackjButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackjButtonActionPerformed
        this.dispose(); // Close the current window
        PurchaseManager_MainPage mainPage = new PurchaseManager_MainPage(); // Create a new instance of the main page
        mainPage.setVisible(true); // Show the main page
    }//GEN-LAST:event_BackjButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PM_ListOfSuppliers.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PM_ListOfSuppliers.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PM_ListOfSuppliers.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PM_ListOfSuppliers.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PM_ListOfSuppliers().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BackjButton;
    private javax.swing.JLabel ListOfSupplierjLabel;
    private javax.swing.JTable ListOfSupplierjTable;
    private com.toedter.calendar.JCalendar SelectDateForFilterjCalendar;
    private javax.swing.JLabel SelectDateForFilterjLabel;
    private javax.swing.JButton ViewjButton;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
